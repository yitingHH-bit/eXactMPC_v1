﻿# eXactMPC_v1

<img width="1008" height="758" alt="image" src="https://github.com/user-attachments/assets/8c4cf0ea-14c7-4d2e-bc93-d1dd1992c443" />


E:/anacoda/python.exe d:/thesis/excavater/code/eXactMPC_v1/Python_fixed/mpc_realtime_gui.py
PS D:\thesis\excavater\code\eXactMPC_v1\Python_fixed> $env:MPC_LOG_RESULTS = "1"
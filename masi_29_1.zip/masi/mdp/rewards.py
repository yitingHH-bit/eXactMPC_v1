from __future__ import annotations

import math
import torch

from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat


# ---------------- quaternion utils (w,x,y,z) ----------------
def _quat_inv(q: torch.Tensor) -> torch.Tensor:
    return torch.stack([q[:, 0], -q[:, 1], -q[:, 2], -q[:, 3]], dim=1)


def _quat_mul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    aw, ax, ay, az = a[:, 0], a[:, 1], a[:, 2], a[:, 3]
    bw, bx, by, bz = b[:, 0], b[:, 1], b[:, 2], b[:, 3]
    return torch.stack(
        [
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ],
        dim=1,
    )


def _quat_rotate(q: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    qw = q[:, 0:1]
    qv = q[:, 1:4]
    uv = torch.cross(qv, v, dim=1)
    uuv = torch.cross(qv, uv, dim=1)
    return v + 2.0 * (qw * uv + uuv)


def _quat_rotate_inv(q: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    return _quat_rotate(_quat_inv(q), v)


def _wrap_to_pi(x: torch.Tensor) -> torch.Tensor:
    return (x + math.pi) % (2 * math.pi) - math.pi


def _yaw_from_quat(q_wxyz: torch.Tensor) -> torch.Tensor:
    w, x, y, z = q_wxyz.unbind(dim=-1)
    t0 = 2.0 * (w * z + x * y)
    t1 = 1.0 - 2.0 * (y * y + z * z)
    return torch.atan2(t0, t1)


def _get_body_id_cached(env: ManagerBasedRLEnv, robot, body_name: str) -> int:
    cache = getattr(env, "_body_id_cache", None)
    if cache is None:
        cache = {}
        env._body_id_cache = cache
    key = (id(robot), body_name)
    if key in cache:
        return cache[key]
    bids, _ = robot.find_bodies([body_name])
    cache[key] = int(bids[0])
    return cache[key]


def joint_pos_rel(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    robot = env.scene[asset_cfg.name]
    q = robot.data.joint_pos
    q0 = getattr(robot.data, "default_joint_pos", None)
    if q0 is None:
        return q
    return q - q0


def joint_vel_rel(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    robot = env.scene[asset_cfg.name]
    qd = robot.data.joint_vel
    qd0 = getattr(robot.data, "default_joint_vel", None)
    if qd0 is None:
        return qd
    return qd - qd0


def log_pos_in_base(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
) -> torch.Tensor:
    """Log position expressed in robot root frame (base translation frame)."""
    robot = env.scene[robot_cfg.name]
    log = env.scene[log_cfg.name]
    root_pos = robot.data.root_state_w[:, 0:3]
    root_quat = robot.data.root_state_w[:, 3:7]
    log_pos = log.data.root_state_w[:, 0:3]
    return _quat_rotate_inv(root_quat, log_pos - root_pos)


def last_action(env: ManagerBasedRLEnv) -> torch.Tensor:
    a = getattr(env.action_manager, "processed_actions", None)
    if a is None:
        a = getattr(env.action_manager, "raw_actions", None)
    if a is None:
        return torch.zeros((env.num_envs, 1), device=env.device)
    return a


# ---------------- rewards ----------------
def ee_to_log_distance_reward(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),
    scale: float = 0.25,
) -> torch.Tensor:
    """Bounded in [0,1]: 1 when close, ~0 when far."""
    device = env.device
    robot = env.scene[robot_cfg.name]
    log = env.scene[log_cfg.name]

    ee_id = _get_body_id_cached(env, robot, ee_body_name)
    ee_pos = robot.data.body_state_w[:, ee_id, 0:3]
    ee_quat = robot.data.body_state_w[:, ee_id, 3:7]
    off = torch.tensor(ee_offset_local, device=device, dtype=ee_pos.dtype).view(1, 3).repeat(env.num_envs, 1)
    tcp = ee_pos + _quat_rotate(ee_quat, off)

    log_pos = log.data.root_state_w[:, 0:3]
    dist = torch.linalg.norm(tcp - log_pos, dim=1)
    return 1.0 - torch.tanh(dist / max(float(scale), 1e-6))


def yaw_alignment_reward(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
    ee_body_name: str = "gripper_frame",
    symmetric: bool = True,
) -> torch.Tensor:
    """Yaw alignment between EE and log around world Z. Output [0,1]."""
    robot = env.scene[robot_cfg.name]
    log = env.scene[log_cfg.name]

    ee_id = _get_body_id_cached(env, robot, ee_body_name)
    ee_quat = robot.data.body_state_w[:, ee_id, 3:7]
    log_quat = log.data.root_state_w[:, 3:7]

    ee_yaw = _yaw_from_quat(ee_quat)
    log_yaw = _yaw_from_quat(log_quat)

    diff = torch.abs(_wrap_to_pi(ee_yaw - log_yaw))
    if symmetric:
        diff = torch.minimum(diff, torch.abs(math.pi - diff))

    # map [0, pi/2] -> [1,0], smooth
    x = torch.clamp(diff / (0.5 * math.pi), 0.0, 1.0)
    return (1.0 - x) ** 4


def vertical_upright_reward(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ee_body_name: str = "gripper_frame",
) -> torch.Tensor:
    """Encourage tool Z axis pointing up in world. Output [0,1]."""
    robot = env.scene[robot_cfg.name]
    ee_id = _get_body_id_cached(env, robot, ee_body_name)
    ee_quat = robot.data.body_state_w[:, ee_id, 3:7]
    R = matrix_from_quat(ee_quat)  # (N,3,3)
    z_axis = R[:, :, 2]            # (N,3)
    return torch.clamp(z_axis[:, 2], 0.0, 1.0) ** 4


def gripper_open_fraction(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    joint_names=("revolute_claw_1", "revolute_claw_2"),
) -> torch.Tensor:
    """0=closed, 1=open (estimated from joint positions and limits)."""
    robot = env.scene[robot_cfg.name]

    cache = getattr(env, "_claw_joint_cache", None)
    if cache is None:
        cache = {}
        env._claw_joint_cache = cache
    key = (id(robot), tuple(joint_names))
    if key not in cache:
        jids, _ = robot.find_joints(list(joint_names))
        # IsaacLab may return list or tensor; normalize to 1D tensor
        if isinstance(jids, (list, tuple)):
            jids = torch.tensor(jids, device=env.device, dtype=torch.long)
        cache[key] = jids[0] if jids.ndim == 2 else jids
    jids = cache[key]

    q = robot.data.joint_pos[:, jids]
    # prefer joint_pos_limits
    lim = getattr(robot.data, "joint_pos_limits", None)
    if lim is None:
        lim = getattr(robot.data, "joint_limits", None)

    if lim is None:
        # fallback: assume negative=open, positive=closed
        openness = torch.sigmoid(-q.mean(dim=1))
        return openness.unsqueeze(1)

    # lim could be (DoF,2) or (N,DoF,2)
    if lim.ndim == 2:
        lo = lim[jids, 0].unsqueeze(0).expand(env.num_envs, -1)
        hi = lim[jids, 1].unsqueeze(0).expand(env.num_envs, -1)
    else:
        lo = lim[:, jids, 0]
        hi = lim[:, jids, 1]

    # normalize: (q - closed)/(open - closed) depends on direction; we choose max range
    # define open as closer to lo, closed closer to hi
    frac = (hi - q) / (hi - lo + 1e-8)  # if q==hi -> 0 (closed), q==lo -> 1 (open)
    frac = torch.clamp(frac, 0.0, 1.0)
    return frac.mean(dim=1, keepdim=True)


def grasp_open_close_reward(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),
    threshold: float = 0.06,
) -> torch.Tensor:
    """Encourage open when far and close when near. Output roughly [0,1]."""
    robot = env.scene[robot_cfg.name]
    log = env.scene[log_cfg.name]

    ee_id = _get_body_id_cached(env, robot, ee_body_name)
    ee_pos = robot.data.body_state_w[:, ee_id, 0:3]
    ee_quat = robot.data.body_state_w[:, ee_id, 3:7]
    off = torch.tensor(ee_offset_local, device=env.device, dtype=ee_pos.dtype).view(1, 3).repeat(env.num_envs, 1)
    tcp = ee_pos + _quat_rotate(ee_quat, off)

    log_pos = log.data.root_state_w[:, 0:3]
    dist = torch.linalg.norm(tcp - log_pos, dim=1)

    open_frac = gripper_open_fraction(env, robot_cfg).squeeze(-1)

    open_far = (dist > float(threshold)).float() * open_frac
    close_near = (dist <= float(threshold)).float() * (1.0 - open_frac)
    return 0.2 * open_far + 0.8 * close_near


def log_lift_reward(
    env: ManagerBasedRLEnv,
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
    base_z: float = 0.05,
    scale: float = 0.05,
) -> torch.Tensor:
    """Bounded lift reward in [0,1] using tanh."""
    log = env.scene[log_cfg.name]
    z = log.data.root_state_w[:, 2]
    dz = torch.clamp(z - float(base_z), min=0.0)
    return torch.tanh(dz / max(float(scale), 1e-6))


def action_rate_l2(env: ManagerBasedRLEnv, clip_per_step: float = 1.0) -> torch.Tensor:
    a = getattr(env.action_manager, "processed_actions", None)
    if a is None:
        a = getattr(env.action_manager, "raw_actions", None)
    if a is None:
        a = torch.zeros((env.num_envs, 1), device=env.device, dtype=torch.float32)

    if not hasattr(env, "_prev_actions"):
        env._prev_actions = torch.zeros_like(a)

    da = a - env._prev_actions
    env._prev_actions = a.detach()

    per_env = torch.sum(da * da, dim=1)
    return torch.clamp(per_env, 0.0, float(clip_per_step))

from __future__ import annotations

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat


def _quat_rotate(q_wxyz: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """Rotate v by quaternion q (wxyz). q:(N,4), v:(N,3)."""
    qw = q_wxyz[:, 0:1]
    qv = q_wxyz[:, 1:4]
    uv = torch.cross(qv, v, dim=1)
    uuv = torch.cross(qv, uv, dim=1)
    return v + 2.0 * (qw * uv + uuv)


@torch.no_grad()
def debug_print_pose(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),
    interval_s: float = 1.0,
):
    """Optional debug event: prints ee/log relative info (very light)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    base_env = env.unwrapped if hasattr(env, "unwrapped") else env
    if not hasattr(base_env, "_dbg_timer_pose"):
        base_env._dbg_timer_pose = torch.zeros(env.num_envs, device=device)

    step_dt = float(getattr(base_env, "step_dt", 1.0 / 60.0))
    base_env._dbg_timer_pose[env_ids] += step_dt
    do_print = base_env._dbg_timer_pose[env_ids] >= float(interval_s)
    if not torch.any(do_print):
        return

    eid = int(env_ids[torch.nonzero(do_print, as_tuple=False)[0, 0]].item())
    base_env._dbg_timer_pose[eid] = 0.0

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # ee body id cache
    cache = getattr(base_env, "_dbg_body_cache", None)
    if cache is None:
        cache = {}
        base_env._dbg_body_cache = cache
    if ee_body_name not in cache:
        bid, _ = robot.find_bodies([ee_body_name])
        cache[ee_body_name] = int(bid[0])
    ee_id = cache[ee_body_name]

    ee_pos = robot.data.body_state_w[eid, ee_id, 0:3].unsqueeze(0)
    ee_quat = robot.data.body_state_w[eid, ee_id, 3:7].unsqueeze(0)
    off = torch.tensor(ee_offset_local, device=device, dtype=ee_pos.dtype).view(1, 3)
    tcp = ee_pos + _quat_rotate(ee_quat, off)

    log_pos = log.data.root_state_w[eid, 0:3]
    d = tcp.squeeze(0) - log_pos
    print(f"[DBG] tcp-log: dx={float(d[0]):+.3f} dy={float(d[1]):+.3f} dz={float(d[2]):+.3f}")

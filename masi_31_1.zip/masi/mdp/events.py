from __future__ import annotations

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import combine_frame_transforms


@torch.no_grad()
def reset_internal_buffers(env: ManagerBasedRLEnv, env_ids: torch.Tensor):
    """Reset per-episode buffers used by custom rewards (action-rate, etc.)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    # action-rate
    if hasattr(env, "_prev_actions"):
        env._prev_actions[env_ids] = 0.0

    # cache: body ids / joint ids are persistent, no need to reset.


@torch.no_grad()
def reset_log_near_robot(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    offset_b=(0.55, 0.0, 0.05),
    circle_radius: float | None = None,
    circle_angle_range=None,
    circle_z: float | None = None,
    yaw_range: float = 0.02,
):
    """Place the log in front of the robot (offset expressed in robot root frame)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    root_pos_w = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]

    if circle_radius is not None:
        angle_min, angle_max = (-3.141592653589793, 3.141592653589793)
        if circle_angle_range is not None:
            if len(circle_angle_range) != 2:
                raise ValueError("circle_angle_range must be a (min, max) tuple.")
            angle_min, angle_max = float(circle_angle_range[0]), float(circle_angle_range[1])
        theta = angle_min + (angle_max - angle_min) * torch.rand(
            (env_ids.numel(),), device=device, dtype=root_pos_w.dtype
        )
        r = torch.full((env_ids.numel(),), float(circle_radius), device=device, dtype=root_pos_w.dtype)
        z_val = float(circle_z) if circle_z is not None else float(offset_b[2])
        off_b = torch.stack([r * torch.cos(theta), r * torch.sin(theta), torch.full_like(r, z_val)], dim=1)
    else:
        off_b = torch.tensor(offset_b, device=device, dtype=root_pos_w.dtype).view(1, 3).repeat(env_ids.numel(), 1)
    log_pos_w, _ = combine_frame_transforms(root_pos_w, root_quat_w, off_b)

    # random yaw (tiny), keep other rotations 0
    if float(yaw_range) > 0.0:
        yaw = (torch.rand((env_ids.numel(),), device=device, dtype=root_pos_w.dtype) - 0.5) * 2.0 * float(yaw_range)
        cy = torch.cos(0.5 * yaw)
        sy = torch.sin(0.5 * yaw)
        log_quat_w = torch.stack([cy, torch.zeros_like(cy), torch.zeros_like(cy), sy], dim=1)
    else:
        log_quat_w = torch.tensor([1.0, 0.0, 0.0, 0.0], device=device, dtype=root_pos_w.dtype).view(1, 4).repeat(env_ids.numel(), 1)

    rs = log.data.root_state_w[env_ids].clone()  # (M,13)
    rs[:, 0:3] = log_pos_w
    rs[:, 3:7] = log_quat_w
    rs[:, 7:13] = 0.0
    log.write_root_state_to_sim(rs, env_ids=env_ids)


@torch.no_grad()
def pull_back_log_if_far(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    offset_b=(0.55, 0.0, 0.05),
    circle_radius: float | None = None,
    circle_angle_range=None,
    circle_z: float | None = None,
    max_dist: float = 0.95,
):
    """If log drifted too far, reset it near robot (safety for training)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    root_pos_w = robot.data.root_state_w[env_ids, 0:3]
    log_pos_w = log.data.root_state_w[env_ids, 0:3]
    dist = torch.linalg.norm(log_pos_w - root_pos_w, dim=1)

    far_mask = dist > float(max_dist)
    if not torch.any(far_mask):
        return

    reset_log_near_robot(
        env,
        env_ids[far_mask],
        robot_asset_cfg,
        log_asset_cfg,
        offset_b=offset_b,
        circle_radius=circle_radius,
        circle_angle_range=circle_angle_range,
        circle_z=circle_z,
    )


@torch.no_grad()
def auto_gripper_close_near_log(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),
    close_dist: float = 0.05,
    open_dist: float = 0.08,
    tool_joint_names=("revolute_claw_1", "revolute_claw_2"),
    open_margin_ratio: float = 0.02,
):
    """Auto-close claws when the TCP is near the log; reopen when far (hysteresis)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]
    base_env = env.unwrapped if hasattr(env, "unwrapped") else env

    if not hasattr(base_env, "_auto_grip_state"):
        base_env._auto_grip_state = torch.zeros(env.num_envs, device=device, dtype=torch.bool)

    # EE body id cache
    cache = getattr(base_env, "_auto_grip_body_cache", None)
    if cache is None:
        cache = {}
        base_env._auto_grip_body_cache = cache
    if ee_body_name not in cache:
        bid, _ = robot.find_bodies([ee_body_name])
        cache[ee_body_name] = int(bid[0])
    ee_id = cache[ee_body_name]

    ee_pos = robot.data.body_state_w[env_ids, ee_id, 0:3]
    ee_quat = robot.data.body_state_w[env_ids, ee_id, 3:7]
    off = torch.tensor(ee_offset_local, device=device, dtype=ee_pos.dtype).view(1, 3).repeat(env_ids.numel(), 1)
    tcp, _ = combine_frame_transforms(ee_pos, ee_quat, off)

    log_pos = log.data.root_state_w[env_ids, 0:3]
    dist = torch.linalg.norm(tcp - log_pos, dim=1)

    close_mask = dist < float(close_dist)
    open_mask = dist > float(open_dist)

    state = base_env._auto_grip_state[env_ids]
    state = torch.where(close_mask, torch.ones_like(state), state)
    state = torch.where(open_mask, torch.zeros_like(state), state)
    base_env._auto_grip_state[env_ids] = state

    # Resolve joint ids
    tool_joint_ids, _ = robot.find_joints(list(tool_joint_names))
    if isinstance(tool_joint_ids, (list, tuple)):
        tool_joint_ids = torch.tensor(tool_joint_ids, device=device, dtype=torch.long)
    elif not isinstance(tool_joint_ids, torch.Tensor):
        tool_joint_ids = torch.tensor([int(tool_joint_ids)], device=device, dtype=torch.long)
    tool_joint_ids = tool_joint_ids.to(device=device, dtype=torch.long).reshape(-1)
    if tool_joint_ids.numel() == 0:
        return

    lim_all = getattr(robot.data, "joint_pos_limits", None)
    if lim_all is None:
        lim_all = getattr(robot.data, "joint_limits", None)
    if lim_all is None:
        return

    lim = lim_all[env_ids[0], tool_joint_ids]
    if lim.ndim == 1:
        lim = lim.unsqueeze(0)
    low = lim[:, 0]
    high = lim[:, 1]

    open_tgt = low.clone()
    close_tgt = high.clone()
    r = float(open_margin_ratio)
    open_tgt = open_tgt * (1.0 - r) + close_tgt * r
    close_tgt = close_tgt * (1.0 - r) + open_tgt * r

    tgt = torch.where(
        state.unsqueeze(1),
        close_tgt.unsqueeze(0).expand(env_ids.numel(), -1),
        open_tgt.unsqueeze(0).expand(env_ids.numel(), -1),
    )

    if tgt.shape[1] != tool_joint_ids.numel():
        tgt = tgt[:, : tool_joint_ids.numel()]

    robot.set_joint_position_target(tgt, joint_ids=tool_joint_ids, env_ids=env_ids)
    robot.write_data_to_sim()

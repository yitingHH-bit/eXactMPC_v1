from __future__ import annotations

from dataclasses import MISSING

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import RelativeJointPositionActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise

try:
    from isaaclab_assets.robots.masiV2 import MASIV2_CFG as MASI_CFG
except Exception:
    from isaaclab_assets.robots.masiV0 import MASI_CFG as MASI_CFG

import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
from .. import mdp  # your local mdp package (events/rewards/news_event)

# -------------------------------------------------------------------------
# Robot / EE definitions
# -------------------------------------------------------------------------
EE_BODY = "gripper_frame"
TCP_OFFSET_LOCAL = (0.0, 0.0, -0.09)  # TCP relative to gripper_frame (local)

# -------------------------------------------------------------------------
# Scene: Excavator + Log
# -------------------------------------------------------------------------
@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    robot: ArticulationCfg = MISSING

    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.05, 0.20, 0.05),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.10),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                static_friction=1.5, dynamic_friction=1.5, restitution=0.0
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(0.55, 0.0, 0.05), rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=2500.0, color=(0.75, 0.75, 0.75)),
    )

# -------------------------------------------------------------------------
# Observations
# -------------------------------------------------------------------------
@configclass
class ObservationsCfg:
    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel, noise=Unoise(n_min=-0.01, n_max=0.01))
        joint_vel = ObsTerm(func=mdp.joint_vel_rel, noise=Unoise(n_min=-0.01, n_max=0.01))

        log_pos_b = ObsTerm(func=mdp.log_pos_in_base)
        gripper_open = ObsTerm(func=mdp.gripper_open_fraction)
        actions = ObsTerm(func=mdp.last_action)

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()

# -------------------------------------------------------------------------
# Actions (DIRECT JOINT ACTION)
# -------------------------------------------------------------------------
@configclass
class ActionsCfg:
    # Main arm joints (match your MASI model; remove a name if your robot doesn't have it)
    arm_action = RelativeJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_cabin", "revolute_lift", "revolute_tilt", "revolute_scoop", "revolute_gripper"],
        scale=0.05,
        use_zero_offset=True,
    )

    # Claw joints (continuous; policy can learn open/close like Direct env)
    gripper_action = RelativeJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_1", "revolute_claw_2"],
        scale=0.2,
        use_zero_offset=True,
    )

# -------------------------------------------------------------------------
# Events
# -------------------------------------------------------------------------
@configclass
class EventCfg:
    reset_robot_joints = EventTerm(
        func=mdp_isaac.reset_joints_by_scale,
        mode="reset",
        params={"position_range": (0.9, 1.1), "velocity_range": (0.0, 0.0)},
    )

    reset_log_near_robot = EventTerm(
        func=mdp.reset_log_near_robot,
        mode="reset",
        params={
            "robot_asset_cfg": SceneEntityCfg("robot"),
            "log_asset_cfg": SceneEntityCfg("log"),
            "offset_b": (0.55, 0.0, 0.05),
            "circle_radius": 0.55,
            "circle_angle_range": (-1.0471975512, 1.0471975512),
            "circle_z": 0.05,
            "yaw_range": 1.5707963267948966,
        },
    )

    reset_internal = EventTerm(func=mdp.reset_internal_buffers, mode="reset", params={})

    # Optional: keep log in range (interval)
    pull_back_log = EventTerm(
        func=mdp.pull_back_log_if_far,
        mode="interval",
        interval_range_s=(0.25, 0.25),
        params={
            "robot_asset_cfg": SceneEntityCfg("robot"),
            "log_asset_cfg": SceneEntityCfg("log"),
            "offset_b": (0.55, 0.0, 0.05),
            "circle_radius": 0.55,
            "circle_angle_range": (-1.0471975512, 1.0471975512),
            "circle_z": 0.05,
            "max_dist": 0.95,
        },
    )

    auto_grip_log = EventTerm(
        func=mdp.auto_gripper_close_near_log,
        mode="interval",
        interval_range_s=(0.05, 0.05),
        params={
            "robot_asset_cfg": SceneEntityCfg("robot"),
            "log_asset_cfg": SceneEntityCfg("log"),
            "ee_body_name": EE_BODY,
            "ee_offset_local": TCP_OFFSET_LOCAL,
            "close_dist": 0.08,
            "open_dist": 0.12,
            "tool_joint_names": ("revolute_claw_1", "revolute_claw_2"),
            "open_margin_ratio": 0.02,
        },
    )

# -------------------------------------------------------------------------
# Terminations
# -------------------------------------------------------------------------
@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp_isaac.time_out, time_out=True)

    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "bounds": {"x": (-3.0, 3.0), "y": (-3.0, 3.0), "z": (-1.0, 3.0)}},
    )

    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"), "ee_body_name": EE_BODY,
                "limit_lin": 1.2, "limit_ang": 10.0},
    )

# -------------------------------------------------------------------------
# Rewards (bounded to avoid value loss explosion)
# -------------------------------------------------------------------------
@configclass
class RewardsCfg:
    ee_to_log = RewTerm(
        func=mdp.ee_to_log_distance_reward,
        weight=3.0,
        params={"robot_cfg": SceneEntityCfg("robot"), "log_cfg": SceneEntityCfg("log"),
                "ee_body_name": EE_BODY, "ee_offset_local": TCP_OFFSET_LOCAL, "scale": 0.25},
    )

    yaw_alignment = RewTerm(
        func=mdp.yaw_alignment_reward,
        weight=0.5,
        params={"robot_cfg": SceneEntityCfg("robot"), "log_cfg": SceneEntityCfg("log"),
                "ee_body_name": EE_BODY, "symmetric": True},
    )

    vertical_upright = RewTerm(
        func=mdp.vertical_upright_reward,
        weight=1.0,
        params={"robot_cfg": SceneEntityCfg("robot"), "ee_body_name": EE_BODY},
    )

    grasp_open_close = RewTerm(
        func=mdp.grasp_open_close_reward,
        weight=0.8,
        params={"robot_cfg": SceneEntityCfg("robot"), "log_cfg": SceneEntityCfg("log"),
                "ee_body_name": EE_BODY, "ee_offset_local": TCP_OFFSET_LOCAL, "threshold": 0.1},
    )

    log_lift = RewTerm(
        func=mdp.log_lift_reward,
        weight=6.0,
        params={"log_cfg": SceneEntityCfg("log"), "base_z": 0.05, "scale": 0.05},
    )

    action_rate = RewTerm(func=mdp.action_rate_l2, weight=-0.01, params={"clip_per_step": 1.0})

# -------------------------------------------------------------------------
# Env
# -------------------------------------------------------------------------
@configclass
class MasiDirectJointReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=512, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.12)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        self.sim.dt = 1.0 / 60.0
        self.decimation = 2
        self.episode_length_s = 12.0
        self.sim.render_interval = self.decimation
        self.sim.gpu_max_rigid_patch_count = 400000

@configclass
class MasiDirectJointReachLogEnvCfg_PLAY(MasiDirectJointReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False

# Backwards-compatible names expected by task registry.
@configclass
class MasiIkReachLogEnvCfg(MasiDirectJointReachLogEnvCfg):
    pass


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiDirectJointReachLogEnvCfg_PLAY):
    pass

from dataclasses import MISSING

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise

import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
try:
    from isaaclab_assets.robots.masiV2 import MASIV2_CFG as MASI_CFG
except Exception:
    from isaaclab_assets.robots.masiV0 import MASI_CFG

from .. import mdp

# -------------------------------------------------------------------------
# EE definition (excavator gripper root frame)
# -------------------------------------------------------------------------
EE_BODY = "ee"

# EE alignment:
#   We use body "ee" as the true tool center point (TCP) in the robot model.
#   Therefore we set TCP offset to zero to avoid double-counting any URDF frame offsets.
TCP_OFFSET_LOCAL = (0.1, 0.0, 0.0)

# -------------------------------------------------------------------------
# Scene
# -------------------------------------------------------------------------
@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    robot: ArticulationCfg = MISSING

    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.04, 0.14, 0.04),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.10),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                static_friction=1.5,
                dynamic_friction=1.5,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(0.7, 0.0, 0.03),
            rot=(1.0, 0.0, 0.0, 0.0),
        ),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )

# -------------------------------------------------------------------------
# Observations
# -------------------------------------------------------------------------
@configclass
class ObservationsCfg:
    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel, noise=Unoise(n_min=-0.01, n_max=0.01))
        joint_vel = ObsTerm(func=mdp.joint_vel_rel, noise=Unoise(n_min=-0.01, n_max=0.01))

        pose_command_ee = ObsTerm(func=mdp.generated_commands, params={"command_name": "ee_pose"})
        log_dir = ObsTerm(func=mdp.log_dir_in_base)
        actions = ObsTerm(func=mdp.last_action)

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()
    
    @configclass    
    class CriticCfg(ObsGroup):
        # (1) 复制 Policy 的内容，但去除噪声 (Noise-free)
        # Critic 不需要被噪声迷惑
        joint_pos = ObsTerm(func=mdp.joint_pos_rel) 
        joint_vel = ObsTerm(func=mdp.joint_vel_rel)
        pose_command_ee = ObsTerm(func=mdp.generated_commands, params={"command_name": "ee_pose"})
        actions = ObsTerm(func=mdp.last_action)

        log_vel = ObsTerm(
            func=mdp.root_lin_vel_w, # 获取世界坐标系下的线速度
            params={"asset_cfg": SceneEntityCfg("log")}
        )
        
      
        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    # 注册 critic 组
    critic: CriticCfg = CriticCfg()
# -------------------------------------------------------------------------
# Actions (ONLY arm joints; gripper is rule-based in event term)
# -------------------------------------------------------------------------
@configclass
class ActionsCfg:
    arm_action = DifferentialInverseKinematicsActionCfg(
        asset_name="robot",
        joint_names=["revolute_lift", "revolute_tilt", "revolute_scoop", "revolute_cabin", "revolute_gripper"],
        body_name=EE_BODY,
        controller=DifferentialIKControllerCfg(
            command_type="position",
            use_relative_mode=True,
            ik_method="dls",
            ik_params={"lambda_val": 0.08},
        ),
        scale=0.01,
        body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(pos=TCP_OFFSET_LOCAL),
    )

# -------------------------------------------------------------------------
# Events
# -------------------------------------------------------------------------
@configclass
class EventCfg:
    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale,
        mode="reset",
        params={"position_range": (0.9, 1.1), "velocity_range": (0.0, 0.0)},
    )

    reset_sync_state = EventTerm(
        func=mdp.reset_sync_ee_pose_state,
        mode="reset",
        params={},
    )

    # keep log near robot at reset (optional)
    reset_log_near_robot = EventTerm(
        func=mdp.reset_log_near_robot,
        mode="reset",
        params={
            "robot_asset_cfg": SceneEntityCfg("robot"),
            "log_asset_cfg": SceneEntityCfg("log"),
            "offset_b": (0.6, 0.0, -0.09),
        },
    )

    # command tracking
    sync_cmd_to_log = EventTerm(
        func=mdp.sync_ee_pose_to_log_two_stage_position_only,
        mode="interval",
        interval_range_s=(0.05, 0.05),
        params={
            "command_name": "ee_pose",
            "robot_asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]),
            "log_asset_cfg": SceneEntityCfg("log"),
            "approach_height": 0.10,
            "descend_xy": 0.06,
            "final_z_offset": 0.0,
            "log_half_height": 0.02,   # log cube 0.04m -> half height 0.02
            "max_pos_step": 0.01,
            "blend": 0.2,
            "lift_z": 0.18,
        },
    )

    # auto grasp (directly sets claw joint targets)
    auto_grasp_log = EventTerm(
        func=mdp.auto_grasp_log_fsm,
        mode="interval",
        interval_range_s=(0.0, 0.0),
        params={
            "robot_asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]),
            "log_asset_cfg": SceneEntityCfg("log"),
            "tcp_offset_local": TCP_OFFSET_LOCAL,
            "tool_joint_names": ("revolute_claw_1", "revolute_claw_2"),
            "close_dist": 0.06,
            "open_dist": 0.10,
            "grasp_hold_steps": 3,
            "lift_steps": 80,
            "lift_height": 0.18,
            "command_name": "ee_pose",
            "debug_print": True,
            "dbg_interval_s": 0.8,
            "close_z_above": 0.05,
            "close_z_below": 0.12,
        },
    )

# -------------------------------------------------------------------------
# Commands
# -------------------------------------------------------------------------
@configclass
class CommandsCfg:
    ee_pose = mdp.UniformPoseCommandCfg(
        asset_name="robot",
        body_name=EE_BODY,
        resampling_time_range=(9999.0, 9999.0),
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(0.6, 0.6),
            pos_y=(0.0, 0.0),
            pos_z=(0.10, 0.10),
            roll=(0.0, 0.0),
            pitch=(0.0, 0.0),
            yaw=(0.0, 0.0),
        ),
    )

# -------------------------------------------------------------------------
# Terminations
# -------------------------------------------------------------------------
@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bounds": {"x": (-3.0, 3.0), "y": (-3.0, 3.0), "z": (-1.0, 3.0)},
        },
    )
    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"), "ee_body_name": EE_BODY, "limit_lin": 0.8, "limit_ang": 6.0},
    )
    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={"asset_cfg": SceneEntityCfg("robot"), "limit_lin": 0.8, "limit_ang": 6.0},
    )
    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"), "bound": 2.5},
    )
    nan_inf_guard = DoneTerm(
        func=mdp.has_nan_or_inf,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

# -------------------------------------------------------------------------
# Rewards
# -------------------------------------------------------------------------
@configclass
class RewardsCfg:
    # ------------------------------------------------------------
    # ✅ Aligned with your DirectRLEnv reward design:
    #   distance (linear) + yaw(symmetric) + vertical(upright) + grasp(open/close) + lift + action_rate penalty
    # ------------------------------------------------------------
    ee_to_log_distance = RewTerm(
        func=mdp.ee_to_log_distance_linear_reward,
        weight=1.0,
        params={
            "robot_cfg": SceneEntityCfg("robot"),
            "log_cfg": SceneEntityCfg("log"),
            "ee_body_name": EE_BODY,
            "ee_offset_local": TCP_OFFSET_LOCAL,
            "distance_scale": 5.0,
        },
    )

    yaw_alignment = RewTerm(
        func=mdp.ee_log_yaw_symmetric_reward,
        weight=1.0,
        params={
            "robot_cfg": SceneEntityCfg("robot"),
            "log_cfg": SceneEntityCfg("log"),
            "ee_body_name": EE_BODY,
            "yaw_weight": 0.5,
        },
    )

    vertical_upright = RewTerm(
        func=mdp.ee_vertical_upright_reward,
        weight=1.0,
        params={
            "robot_cfg": SceneEntityCfg("robot"),
            "ee_body_name": EE_BODY,
            "upright_weight": 1.0,
        },
    )

    grasp_open_close = RewTerm(
        func=mdp.gripper_open_close_distance_reward,
        weight=1.0,
        params={
            "robot_cfg": SceneEntityCfg("robot"),
            "log_cfg": SceneEntityCfg("log"),
            "ee_body_name": EE_BODY,
            "ee_offset_local": TCP_OFFSET_LOCAL,
            "threshold": 0.05,
            "open_far_gain": 0.2,
            "close_near_gain": 0.5,
            "claw_joint_names": ("revolute_claw_1", "revolute_claw_2"),
            # match your DirectRLEnv values:
            "open_position": -50.0 * (3.14159 / 180.0),
            "closed_position": 29.0 * (3.14159 / 180.0),
        },
    )

    log_lift = RewTerm(
        func=mdp.log_lift_linear_reward,
        weight=1.0,
        params={
            "log_cfg": SceneEntityCfg("log"),
            # init_state.z in this env config is 0.03
            "log_z0": 0.03,
            "lift_scale": 100.0,
        },
    )

    action_rate = RewTerm(func=mdp.safe_action_rate_l2, weight=-0.001)


# -------------------------------------------------------------------------
# Env
# -------------------------------------------------------------------------
@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=1024, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.12)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        self.sim.dt = 1.0 / 60.0
        self.decimation = 2
        self.episode_length_s = 12.0
        self.sim.render_interval = self.decimation


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
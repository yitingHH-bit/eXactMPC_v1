﻿# eXactMPC_v1

<img width="1008" height="758" alt="image" src="https://github.com/user-attachments/assets/8c4cf0ea-14c7-4d2e-bc93-d1dd1992c443" />
